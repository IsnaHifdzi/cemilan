package com.example.myklass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyklassApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyklassApplication.class, args);
	}

}
