package praktek.array.array;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArrayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArrayApplication.class, args);
	}

}
