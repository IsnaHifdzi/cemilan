package javabasic.ti.c.javabesic.praktek.empat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavabesicPraktekEmpatApplicationTests {

	@Test
	void contextLoads() {
	}

}
